import express from "express";
import path from "path";
import cors from "cors";
import fs from "fs";
import alasql from "alasql";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";
import { createServer as createViteServer } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: "20mb" }));

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Initialize Pure-JS in-memory SQL database with JSON file persistence
const JSON_DB_FILE = path.join(__dirname, "omnipse_db.json");

function saveDatabaseToDisk() {
  try {
    const tables = ["hard_constraints", "pipelines", "pipeline_stages", "habits", "agent_logs"];
    const dbData: Record<string, any[]> = {};
    for (const table of tables) {
      try {
        dbData[table] = alasql(`SELECT * FROM ${table}`) || [];
      } catch (e) {
        dbData[table] = [];
      }
    }
    fs.writeFileSync(JSON_DB_FILE, JSON.stringify(dbData, null, 2), "utf8");
    console.log("Database saved to disk successfully.");
  } catch (err) {
    console.error("Failed to save database to disk:", err);
  }
}

function loadDatabaseFromDisk() {
  try {
    if (fs.existsSync(JSON_DB_FILE)) {
      const dataStr = fs.readFileSync(JSON_DB_FILE, "utf8");
      const dbData = JSON.parse(dataStr);
      for (const table in dbData) {
        if (Array.isArray(dbData[table]) && dbData[table].length > 0) {
          try {
            alasql(`DELETE FROM ${table}`);
          } catch (e) {}
          
          for (const row of dbData[table]) {
            const keys = Object.keys(row);
            const placeholders = keys.map(() => "?").join(", ");
            const columns = keys.join(", ");
            const values = Object.values(row);
            try {
              alasql(`INSERT INTO ${table} (${columns}) VALUES (${placeholders})`, values);
            } catch (insertErr) {
              console.error(`Error loading row into ${table}:`, insertErr);
            }
          }
        }
      }
      console.log("Database loaded from disk successfully.");
    }
  } catch (err) {
    console.error("Failed to load database from disk:", err);
  }
}

// Helper to rewrite query syntax compatibility for alasql (reserved keywords like count)
function rewriteSQL(sql: string): string {
  return sql.replace(/count\(\*\)\s+as\s+count/gi, "COUNT(*) AS cnt")
            .replace(/count\(\*\)\s+count/gi, "COUNT(*) AS cnt");
}

function mapResult(res: any): any {
  if (res && typeof res === "object") {
    if (Array.isArray(res)) {
      return res.map(row => mapResult(row));
    }
    if ("cnt" in res) {
      res.count = res.cnt;
    }
  }
  return res;
}

// Promisified database methods using alasql
async function dbRun(sql: string, params: any[] = []): Promise<{ lastID: number; changes: number }> {
  try {
    const finalSql = rewriteSQL(sql);
    const res = alasql(finalSql, params);
    
    // Save database state to disk on any mutations
    const isMutation = !/^\s*select/i.test(sql);
    if (isMutation) {
      saveDatabaseToDisk();
    }

    let lastID = 0;
    const insertRegex = /insert\s+into\s+([a-zA-Z0-9_]+)/i;
    const match = sql.match(insertRegex);
    if (match && match[1]) {
      const tableName = match[1];
      try {
        const idRes = alasql(`SELECT MAX(id) AS id FROM ${tableName}`);
        if (idRes && idRes[0] && idRes[0].id) {
          lastID = Number(idRes[0].id);
        }
      } catch (e) {}
    }

    const changes = typeof res === "number" ? res : (Array.isArray(res) ? res.length : 1);
    return { lastID, changes };
  } catch (err: any) {
    console.error("Database run error:", err, "SQL:", sql, "Params:", params);
    throw err;
  }
}

async function dbGet(sql: string, params: any[] = []): Promise<any> {
  try {
    const finalSql = rewriteSQL(sql);
    const res = alasql(finalSql, params);
    if (Array.isArray(res) && res.length > 0) {
      return mapResult(res[0]);
    }
    return null;
  } catch (err: any) {
    console.error("Database get error:", err, "SQL:", sql, "Params:", params);
    throw err;
  }
}

async function dbAll(sql: string, params: any[] = []): Promise<any[]> {
  try {
    const finalSql = rewriteSQL(sql);
    const res = alasql(finalSql, params);
    if (Array.isArray(res)) {
      return mapResult(res);
    }
    return [];
  } catch (err: any) {
    console.error("Database all error:", err, "SQL:", sql, "Params:", params);
    throw err;
  }
}

// Database Schema Initialization
async function initDatabase() {
  console.log("Initializing Scalable Database...");

  // 1. Immutable Lifecycle Commitments
  await dbRun(`
    CREATE TABLE IF NOT EXISTS hard_constraints (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL, -- 'timetable', 'exam', 'medical'
      title TEXT NOT NULL,
      start_time TEXT NOT NULL, -- HH:MM (for repeating) or ISO timestamp
      end_time TEXT NOT NULL,   -- HH:MM (for repeating) or ISO timestamp
      days_of_week TEXT,        -- comma-separated: '1,2,3,4,5' (for repeating timetables)
      date TEXT,                -- 'YYYY-MM-DD' (for specific exams/medical blocks)
      importance_percentage INTEGER DEFAULT 80
    )
  `);

  // 2. Polymorphic Pipelines
  await dbRun(`
    CREATE TABLE IF NOT EXISTS pipelines (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      pipeline_name TEXT NOT NULL,
      track_type TEXT NOT NULL, -- 'Career', 'Academic', 'Independent'
      created_at TEXT NOT NULL
    )
  `);

  // 3. Polymorphic Pipeline Stages
  await dbRun(`
    CREATE TABLE IF NOT EXISTS pipeline_stages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pipeline_id INTEGER NOT NULL,
      stage_name TEXT NOT NULL,
      position_order INTEGER NOT NULL,
      status TEXT DEFAULT 'pending', -- 'pending', 'completed', 'missed'
      deadline TEXT,                -- ISO timestamp
      duration_minutes INTEGER DEFAULT 60,
      cognitive_load TEXT DEFAULT 'medium', -- 'high', 'medium', 'low'
      scheduled_start TEXT,         -- ISO timestamp
      scheduled_end TEXT,           -- ISO timestamp
      buffer_minutes INTEGER DEFAULT 10,
      post_mortem_submitted INTEGER DEFAULT 0,
      post_mortem_response TEXT,
      up_skilling_objective TEXT,
      up_skilling_syllabus TEXT,
      importance_percentage INTEGER DEFAULT 60,
      scratchpad TEXT,
      FOREIGN KEY(pipeline_id) REFERENCES pipelines(id) ON DELETE CASCADE
    )
  `);

  // 4. Habits
  await dbRun(`
    CREATE TABLE IF NOT EXISTS habits (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      type TEXT NOT NULL, -- 'micro-habit', 'flexible-habit'
      active INTEGER DEFAULT 1, -- 0 or 1
      duration_minutes INTEGER DEFAULT 15,
      scheduled_start TEXT,
      scheduled_end TEXT,
      importance_percentage INTEGER DEFAULT 40
    )
  `);

  // 5. Agent Logs
  await dbRun(`
    CREATE TABLE IF NOT EXISTS agent_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp TEXT NOT NULL,
      message TEXT NOT NULL,
      category TEXT NOT NULL -- 'ingestion', 'scheduling', 'governor', 'retrospective'
    )
  `);

  // Load any previously persisted data from JSON file database
  loadDatabaseFromDisk();

  // Migrate or Seed default hard constraints and habits if empty
  const constraintsCount = await dbGet("SELECT COUNT(*) as count FROM hard_constraints");
  if (constraintsCount.count === 0) {
    console.log("Seeding universal Immutable Lifecycle Commitments...");
    await dbRun(
      `INSERT INTO hard_constraints (type, title, start_time, end_time, days_of_week, importance_percentage) VALUES (?, ?, ?, ?, ?, ?)`,
      ["timetable", "Standard Work/Class Blocks", "09:00", "16:00", "1,2,3,4,5", 60]
    );
    await dbRun(
      `INSERT INTO hard_constraints (type, title, start_time, end_time, date, importance_percentage) VALUES (?, ?, ?, ?, ?, ?)`,
      ["exam", "Critical Project / Exam Presentation", "2026-07-02T10:00:00-07:00", "2026-07-02T13:00:00-07:00", "2026-07-02", 100]
    );
  }

  // Seed default pipelines and stages if empty
  const pipelinesCount = await dbGet("SELECT COUNT(*) as count FROM pipelines");
  if (pipelinesCount.count === 0) {
    console.log("Seeding polymorphic default tracks...");
    
    // AWS Solutions Architect Certification (Independent)
    const p1 = await dbRun(
      "INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)",
      ["default_user", "AWS Solutions Architect", "Independent", new Date().toISOString()]
    );
    await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, importance_percentage) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [p1.lastID, "Cloud Practitioner Essentials", 0, "pending", new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(), 60, "low", 50]
    );
    await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, importance_percentage) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [p1.lastID, "Core Services Deep-Dive", 1, "pending", new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), 90, "high", 75]
    );

    // Math Grade 11 Calculus (Academic)
    const p2 = await dbRun(
      "INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)",
      ["default_user", "Grade 11 Calculus", "Academic", new Date().toISOString()]
    );
    await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, importance_percentage) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [p2.lastID, "Limits & Continuity Diagnostic", 0, "pending", new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), 60, "medium", 60]
    );
    await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, importance_percentage) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [p2.lastID, "Calculus Mid-Term Exam", 1, "pending", new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(), 120, "high", 90]
    );

    // Google Software Engineer Role (Career)
    const p3 = await dbRun(
      "INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)",
      ["default_user", "Google SE Recruitment", "Career", new Date().toISOString()]
    );
    await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, importance_percentage) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [p3.lastID, "Online Technical Assessment", 0, "pending", new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(), 90, "high", 95]
    );
  }

  const habitsCount = await dbGet("SELECT COUNT(*) as count FROM habits");
  if (habitsCount.count === 0) {
    console.log("Seeding default habits...");
    await dbRun(`INSERT INTO habits (title, type, active, duration_minutes, importance_percentage) VALUES (?, ?, ?, ?, ?)`, [
      "15-min System Design Review",
      "micro-habit",
      1,
      15,
      50
    ]);
    await dbRun(`INSERT INTO habits (title, type, active, duration_minutes, importance_percentage) VALUES (?, ?, ?, ?, ?)`, [
      "LeetCode Daily Problem",
      "flexible-habit",
      1,
      45,
      40
    ]);
  }

  const logsCount = await dbGet("SELECT COUNT(*) as count FROM agent_logs");
  if (logsCount.count === 0) {
    await logAgent(
      "Kairos AI Core Initialization complete. Standing by for Student/User Data Ingestion.",
      "governor"
    );
  }
}

// Log formatting helper
async function logAgent(
  message: string,
  category: 'ingestion' | 'scheduling' | 'governor' | 'retrospective' | 'urgency_sentinel' | 'burnout_governor' | 'chrono_gatekeeper' | 'habit_architect' | 'skill_synthesizer' | 'admin_quartermaster' | 'focus_guardian'
) {
  const timestamp = new Date().toISOString();
  console.log(`[AGENT LOG] [${category.toUpperCase()}] ${message}`);
  await dbRun("INSERT INTO agent_logs (timestamp, message, category) VALUES (?, ?, ?)", [
    timestamp,
    message,
    category,
  ]);
}

// runCognitiveCouncilDeliberation is deprecated as we run everything in a single API call inside optimizeAllSchedules.
async function runCognitiveCouncilDeliberation(triggerEvent: string) {
  // Deprecated
}

// Check and mark passed pending stages as 'missed'
async function autoUpdateMissedTasks() {
  const now = new Date().toISOString();
  const result = await dbRun(
    `UPDATE pipeline_stages SET status = 'missed' WHERE status = 'pending' AND scheduled_end < ?`,
    [now]
  );
  if (result.changes > 0) {
    await logAgent(`Auto-identified and marked ${result.changes} past stages/tasks as 'missed'.`, "governor");
  }
}

// Helper: Calculate Rolling 48-Hour Compliance Metric
async function calculateCompliance(): Promise<number> {
  await autoUpdateMissedTasks();
  const fortyEightHoursAgo = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString();

  const tasks = await dbAll(
    `SELECT status FROM pipeline_stages WHERE scheduled_end >= ? AND status IN ('completed', 'missed')`,
    [fortyEightHoursAgo]
  );

  if (tasks.length === 0) {
    return 100; // Default to 100% compliance if no items
  }

  const completed = tasks.filter((t) => t.status === "completed").length;
  const total = tasks.length;
  return Math.round((completed / total) * 100);
}

// Helper: Check if there is an urgent OA or Interview within 48 hours
async function getUrgentPlacementTask(): Promise<any | null> {
  const now = new Date();
  const fortyEightHoursAhead = new Date(now.getTime() + 48 * 60 * 60 * 1000).toISOString();
  const nowISO = now.toISOString();

  // Find placement stages due in the next 48 hours that are pending
  const task = await dbGet(
    `SELECT ps.*, p.pipeline_name 
     FROM pipeline_stages ps
     JOIN pipelines p ON ps.pipeline_id = p.id
     WHERE (ps.stage_name LIKE '%OA%' OR ps.stage_name LIKE '%Interview%' OR ps.stage_name LIKE '%Assessment%' OR ps.stage_name LIKE '%Test%' OR ps.stage_name LIKE '%Exam%')
     AND ps.status = 'pending' 
     AND ps.deadline >= ? AND ps.deadline <= ?
     ORDER BY ps.deadline ASC LIMIT 1`,
    [nowISO, fortyEightHoursAhead]
  );
  return task || null;
}

// Helper: Parse hours & minutes from time strings
function parseHHMM(timeStr: string): { hours: number; minutes: number } {
  const [h, m] = timeStr.split(":").map(Number);
  return { hours: h, minutes: m };
}

// Core Scheduling Logic: Find earliest open slot for a task duration
async function findEarliestSlot(
  taskDuration: number,
  bufferMinutes: number,
  isHighCognitive: boolean,
  targetDateStr?: string
): Promise<{ start: string; end: string } | null> {
  const now = new Date();
  let currentScanDate = targetDateStr ? new Date(targetDateStr) : new Date();

  // Set start time of scanner to 15-minute intervals
  if (!targetDateStr) {
    const minutes = currentScanDate.getMinutes();
    const nextQuarter = Math.ceil(minutes / 15) * 15;
    currentScanDate.setMinutes(nextQuarter);
    currentScanDate.setSeconds(0);
    currentScanDate.setMilliseconds(0);
  } else {
    currentScanDate.setHours(8, 0, 0, 0);
  }

  // Scan up to 14 days ahead
  for (let dayOffset = 0; dayOffset < 14; dayOffset++) {
    const activeDay = new Date(currentScanDate.getTime() + dayOffset * 24 * 60 * 60 * 1000);
    const dayStr = activeDay.toISOString().split("T")[0];

    // Define scanning range of the day: 8 AM to 10 PM
    const dayStart = new Date(activeDay);
    dayStart.setHours(8, 0, 0, 0);
    const dayEnd = new Date(activeDay);
    dayEnd.setHours(22, 0, 0, 0);

    // If activeDay is today, scanning cannot start before 'now'
    let scanStart = dayStart.getTime() > now.getTime() ? dayStart.getTime() : now.getTime();
    const scanEnd = dayEnd.getTime();

    if (scanStart >= scanEnd) {
      continue; // Skip if today's window is already past
    }

    // Pacing Rule Check: Limit maximum number of high-cognitive items per day to 2
    if (isHighCognitive) {
      const highCognitiveTasksCount = await dbGet(
        `SELECT COUNT(*) as count FROM pipeline_stages 
         WHERE date(scheduled_start) = ? AND cognitive_load = 'high'`,
        [dayStr]
      );
      if (highCognitiveTasksCount.count >= 2) {
        continue;
      }
    }

    // Gather all blocked blocks on this day
    const blockedBlocks: { start: number; end: number }[] = [];

    // 1. Fetch Repeating Timetables / Shift blocks
    const dayOfWeek = activeDay.getDay(); // 0-6 (Sun-Sat)
    const timetables = await dbAll(
      `SELECT * FROM hard_constraints WHERE type = 'timetable'`
    );
    for (const tt of timetables) {
      const days = (tt.days_of_week || "").split(",").map(Number);
      if (days.includes(dayOfWeek)) {
        const { hours: sh, minutes: sm } = parseHHMM(tt.start_time);
        const { hours: eh, minutes: em } = parseHHMM(tt.end_time);

        const ttStart = new Date(activeDay);
        ttStart.setHours(sh, sm, 0, 0);
        const ttEnd = new Date(activeDay);
        ttEnd.setHours(eh, em, 0, 0);

        blockedBlocks.push({ start: ttStart.getTime(), end: ttEnd.getTime() });
      }
    }

    // 2. Fetch One-Off Hard Constraints on this specific date
    const dateConstraints = await dbAll(
      `SELECT * FROM hard_constraints WHERE type IN ('exam', 'medical') AND date = ?`,
      [dayStr]
    );
    for (const dc of dateConstraints) {
      const sTime = new Date(dc.start_time).getTime();
      const eTime = new Date(dc.end_time).getTime();
      blockedBlocks.push({ start: sTime, end: eTime });
    }

    // 3. Fetch Already Scheduled Stages on this specific day
    const scheduledTasks = await dbAll(
      `SELECT scheduled_start, scheduled_end, buffer_minutes FROM pipeline_stages 
       WHERE date(scheduled_start) = ? AND status = 'pending'`,
      [dayStr]
    );
    for (const t of scheduledTasks) {
      const sTime = new Date(t.scheduled_start).getTime();
      const totalBuffer = (t.buffer_minutes || 0) * 60 * 1000;
      const eTime = new Date(t.scheduled_end).getTime() + totalBuffer;
      blockedBlocks.push({ start: sTime, end: eTime });
    }

    // 4. Fetch Scheduled Habits on this specific day
    const scheduledHabits = await dbAll(
      `SELECT scheduled_start, scheduled_end FROM habits 
       WHERE date(scheduled_start) = ? AND active = 1`,
      [dayStr]
    );
    for (const h of scheduledHabits) {
      if (h.scheduled_start && h.scheduled_end) {
        blockedBlocks.push({
          start: new Date(h.scheduled_start).getTime(),
          end: new Date(h.scheduled_end).getTime(),
        });
      }
    }

    // Sort blocked blocks by start time
    blockedBlocks.sort((a, b) => a.start - b.start);

    // Merge overlapping/contiguous blocked blocks
    const mergedBlocks: { start: number; end: number }[] = [];
    for (const block of blockedBlocks) {
      if (mergedBlocks.length === 0) {
        mergedBlocks.push(block);
      } else {
        const last = mergedBlocks[mergedBlocks.length - 1];
        if (block.start <= last.end) {
          last.end = Math.max(last.end, block.end);
        } else {
          mergedBlocks.push(block);
        }
      }
    }

    // Scan for the first open block within [scanStart, scanEnd] that fits (taskDuration + bufferMinutes)
    const requiredTotalDuration = (taskDuration + bufferMinutes) * 60 * 1000;
    let tempStart = scanStart;

    let foundSlotStart = -1;

    for (const block of mergedBlocks) {
      if (block.start > tempStart) {
        const availableSpace = block.start - tempStart;
        if (availableSpace >= requiredTotalDuration) {
          foundSlotStart = tempStart;
          break;
        }
      }
      tempStart = Math.max(tempStart, block.end);
    }

    // Check final gap after the last block until scanEnd
    if (foundSlotStart === -1 && scanEnd - tempStart >= requiredTotalDuration) {
      foundSlotStart = tempStart;
    }

    if (foundSlotStart !== -1) {
      const slotStartISO = new Date(foundSlotStart).toISOString();
      const slotEndISO = new Date(foundSlotStart + taskDuration * 60 * 1000).toISOString();
      return { start: slotStartISO, end: slotEndISO };
    }
  }

  return null;
}

// Strict temporal validation check helper
export function checkTemporalOverlap(startA: string | Date, endA: string | Date, startB: string | Date, endB: string | Date): boolean {
  const sA = new Date(startA).getTime();
  const eA = new Date(endA).getTime();
  const sB = new Date(startB).getTime();
  const eB = new Date(endB).getTime();
  return Math.max(sA, sB) < Math.min(eA, eB);
}

// Google Calendar API Sync Simulation Structure
async function syncToGoogleCalendar(title: string, start: Date, end: Date, importance: number) {
  // Mock Google Calendar API integration
  console.log(`[GOOGLE CALENDAR API SYNC] Syncing "${title}" (${start.toISOString()} - ${end.toISOString()})`);
  await logAgent(`[Google_Calendar_Sync_Engine]: Synchronized scheduled block "${title}" [${start.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} - ${end.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}] (Priority Weight: ${importance}%) to primary Google Calendar. Status: SUCCESS.`, "scheduling");
}

// Core Database Task De-confliction Engine
async function deconflictAllSchedules() {
  const now = new Date();
  const scanDays = 14;
  
  // 1. Fetch pending stages with scheduled times
  const stages = await dbAll(
    "SELECT * FROM pipeline_stages WHERE status = 'pending' AND scheduled_start IS NOT NULL AND scheduled_end IS NOT NULL"
  );
  
  // 2. Fetch active habits with scheduled times
  const habits = await dbAll(
    "SELECT * FROM habits WHERE active = 1 AND scheduled_start IS NOT NULL AND scheduled_end IS NOT NULL"
  );
  
  // 3. Fetch hard constraints
  const constraints = await dbAll("SELECT * FROM hard_constraints");
  
  interface Block {
    dbId: number;
    dbType: 'task' | 'habit' | 'constraint';
    title: string;
    start: Date;
    end: Date;
    importance: number;
    duration: number; // in minutes
    immutable: boolean;
  }
  
  const blocks: Block[] = [];
  
  // Add hard constraints (One-off)
  for (const c of constraints) {
    if (c.type === 'exam' || c.type === 'medical') {
      if (c.start_time && c.end_time) {
        blocks.push({
          dbId: c.id,
          dbType: 'constraint',
          title: c.title,
          start: new Date(c.start_time),
          end: new Date(c.end_time),
          importance: c.importance_percentage || 80,
          duration: Math.round((new Date(c.end_time).getTime() - new Date(c.start_time).getTime()) / 60000),
          immutable: true
        });
      }
    }
  }
  
  // Repeating timetable constraints expanded for 14 days:
  for (let d = 0; d < scanDays; d++) {
    const activeDay = new Date(now.getTime() + d * 24 * 60 * 60 * 1000);
    const dayOfWeek = activeDay.getDay(); // 0 (Sun) to 6 (Sat)
    
    for (const c of constraints) {
      if (c.type === 'timetable') {
        const days = (c.days_of_week || "").split(",").map(Number);
        if (days.includes(dayOfWeek)) {
          const [sh, sm] = c.start_time.split(":").map(Number);
          const [eh, em] = c.end_time.split(":").map(Number);
          
          const start = new Date(activeDay);
          start.setHours(sh, sm, 0, 0);
          const end = new Date(activeDay);
          end.setHours(eh, em, 0, 0);
          
          blocks.push({
            dbId: c.id,
            dbType: 'constraint',
            title: c.title,
            start,
            end,
            importance: c.importance_percentage || 80,
            duration: (eh * 60 + em) - (sh * 60 + sm),
            immutable: true
          });
        }
      }
    }
  }
  
  // Add tasks
  for (const s of stages) {
    blocks.push({
      dbId: s.id,
      dbType: 'task',
      title: s.stage_name,
      start: new Date(s.scheduled_start),
      end: new Date(s.scheduled_end),
      importance: s.importance_percentage || 60,
      duration: s.duration_minutes || 60,
      immutable: false
    });
  }
  
  // Add habits
  for (const h of habits) {
    blocks.push({
      dbId: h.id,
      dbType: 'habit',
      title: h.title,
      start: new Date(h.scheduled_start),
      end: new Date(h.scheduled_end),
      importance: h.importance_percentage || 40,
      duration: h.duration_minutes || 15,
      immutable: false
    });
  }
  
  const mutableBlocks = blocks.filter(b => !b.immutable);
  const immutableBlocks = blocks.filter(b => b.immutable);
  
  // Sort mutable blocks by importance DESC, then start time ASC
  mutableBlocks.sort((a, b) => {
    if (b.importance !== a.importance) {
      return b.importance - a.importance;
    }
    return a.start.getTime() - b.start.getTime();
  });
  
  const placedBlocks: Block[] = [...immutableBlocks];
  
  for (const b of mutableBlocks) {
    let resolved = false;
    let attempts = 0;
    const maxAttempts = 100; // prevent infinite loops
    
    while (!resolved && attempts < maxAttempts) {
      attempts++;
      let overlapWith: Block | null = null;
      
      // Check overlap with any already placed block
      for (const p of placedBlocks) {
        if (checkTemporalOverlap(b.start, b.end, p.start, p.end)) {
          // Check for Controlled Breach
          const isControlledBreach = b.dbType === 'task' && p.dbType === 'constraint' && b.importance >= 85 && b.importance > p.importance;
          if (isControlledBreach) {
            // Under absolute compliance, authorize a Controlled Breach: ignore the lecture constraint for this task
            continue;
          }
          
          overlapWith = p;
          break;
        }
      }
      
      if (overlapWith) {
        // Shift b forward to start after overlapWith's end time plus 10 minutes protective gap
        const newStart = new Date(overlapWith.end.getTime() + 10 * 60 * 1000);
        
        // Ensure within daily scheduling range: 8:00 AM to 10:00 PM
        // If the shifted block goes past 10:00 PM, move to 8:00 AM the next day
        const dayEnd = new Date(newStart);
        dayEnd.setHours(22, 0, 0, 0);
        
        if (newStart.getTime() + b.duration * 60 * 1000 > dayEnd.getTime()) {
          // Move to 8:00 AM of next day
          newStart.setDate(newStart.getDate() + 1);
          newStart.setHours(8, 0, 0, 0);
        }
        
        b.start = newStart;
        b.end = new Date(newStart.getTime() + b.duration * 60 * 1000);
      } else {
        resolved = true;
      }
    }
    
    // Lock in the block
    placedBlocks.push(b);
    
    // Simulate active Google Calendar syncing
    await syncToGoogleCalendar(b.title, b.start, b.end, b.importance);
  }
  
  // Write finalized conflict-free times back to database
  for (const b of placedBlocks) {
    if (b.immutable) continue;
    
    const startStr = b.start.toISOString();
    const endStr = b.end.toISOString();
    
    if (b.dbType === 'task') {
      await dbRun(
        "UPDATE pipeline_stages SET scheduled_start = ?, scheduled_end = ? WHERE id = ?",
        [startStr, endStr, b.dbId]
      );
    } else if (b.dbType === 'habit') {
      await dbRun(
        "UPDATE habits SET scheduled_start = ?, scheduled_end = ? WHERE id = ?",
        [startStr, endStr, b.dbId]
      );
    }
  }
  
  await logAgent("Temporal de-confliction engine completed successfully: zero overlaps remaining across identical slots.", "scheduling");
}

// Function to reschedule all active schedules to optimize earliest slot mapping using exactly ONE single API call to Gemini 1.5 Pro
async function optimizeAllSchedules() {
  await logAgent("Initiating Ultimate 7-Agent Cognitive Council single-invocation deliberation...", "scheduling");

  // Get active Burnout Governor profile variables
  const compliance = await calculateCompliance();
  const urgentTask = await getUrgentPlacementTask();

  let mode: "Recovery" | "Thriving" | "Balanced" = "Balanced";
  if (urgentTask) {
    mode = "Balanced"; // Hyper-Focus override will activate specifically
  } else if (compliance < 60) {
    mode = "Recovery";
  } else if (compliance >= 95) {
    mode = "Thriving";
  }

  // Fetch all pending stages with their associated pipelines
  const pendingStages = await dbAll(`
    SELECT ps.*, p.pipeline_name, p.track_type 
    FROM pipeline_stages ps
    JOIN pipelines p ON ps.pipeline_id = p.id
    WHERE ps.status = 'pending'
    ORDER BY ps.deadline ASC
  `);

  const activeHabits = await dbAll("SELECT * FROM habits WHERE active = 1");
  const hardConstraints = await dbAll("SELECT * FROM hard_constraints");

  // Clear existing schedules for fresh eager scheduling
  await dbRun("UPDATE pipeline_stages SET scheduled_start = NULL, scheduled_end = NULL");
  await dbRun("UPDATE habits SET scheduled_start = NULL, scheduled_end = NULL");

  // Format context for Gemini
  const now = new Date();
  const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const formattedNow = `${daysOfWeek[now.getDay()]}, ${now.toLocaleDateString()} ${now.toLocaleTimeString()}`;

  const context = `
Current Timestamp: ${formattedNow} (ISO: ${now.toISOString()})
Task Compliance Index: ${compliance}%
Burnout Governor Pacing Mode: ${mode}${urgentTask ? " (Hyper-Focus Override Active)" : ""}
Urgent Overriding Task: ${urgentTask ? JSON.stringify(urgentTask) : "None"}

Pending Stages to Schedule:
${JSON.stringify(pendingStages.map(s => ({
  id: s.id,
  stage_name: s.stage_name,
  pipeline_name: s.pipeline_name,
  track_type: s.track_type,
  duration_minutes: s.duration_minutes,
  cognitive_load: s.cognitive_load,
  deadline: s.deadline,
  importance_percentage: s.importance_percentage || 60
})))}

Active Habits to Schedule:
${JSON.stringify(activeHabits.map(h => ({
  id: h.id,
  title: h.title,
  type: h.type,
  duration_minutes: h.duration_minutes,
  importance_percentage: h.importance_percentage || 40
})))}

Active Immutable Hard Constraints (Chrono-Shield):
${JSON.stringify(hardConstraints.map(c => ({
  id: c.id,
  title: c.title,
  type: c.type,
  start_time: c.start_time,
  end_time: c.end_time,
  days_of_week: c.days_of_week,
  date: c.date,
  importance_percentage: c.importance_percentage || 80
})))}
`;

  const prompt = `You are the "7-Agent Cognitive Council" of Kairos AI.
Your purpose is to conduct a collaborative multi-turn deliberation debate regarding the system's schedule velocity, safety boundaries, administrative logistics, deep work intervals, and recent changes.
Then, as the consensus resolution of your debate, you must allocate non-overlapping, optimized time slots (scheduled_start and scheduled_end) for all pending stages and active habits.

Council Entities:
1. 'Urgency_Sentinel' - Enforces absolute deadline, OA, and milestone compliance.
2. 'Burnout_Governor' - Protects mental bandwidth and regulates Task Compliance pacing rules.
3. 'Chrono_Gatekeeper' - Protects immutable physical and institutional constraints (timetables, classes).
4. 'Habit_Architect' - Injects micro-habits and systematically eliminates open timeline gaps.
5. 'Skill_Synthesizer' - Evaluates qualitative user post-mortem text and generates remedial upskilling plans.
6. 'Admin_Quartermaster' - Identifies and schedules mundane logistical and administrative tasks (bills, renewals).
7. 'Focus_Guardian' - Regulates human execution layer by optimizing deep-work intervals and scheduling recovery breaks.

Review this context:
${context}

Your output MUST be a single, unified JSON payload containing:
1. "dialogue": A simulated multi-turn debate dialogue between all seven specific agents (8 turns: one for each agent, plus a final cooperative "Resolution" statement from the Council).
2. "schedule_modifications": The consensus resolution containing the final optimized schedule slots (scheduled_start and scheduled_end ISO strings) for each pending stage and habit.

Strategic Breach Negotiation & Utility Weighting Rules:
- If a highly urgent, high-importance milestone (e.g. an elite placement round or critical submission with importance_percentage >= 85%) directly conflicts with a Chrono-Shield constraint (e.g., standard lecture block):
  - Instruct 'Urgency_Sentinel' and 'Chrono_Gatekeeper' to calculate the utility differential: if the task's importance percentage exceeds the constraint's weight, the council must execute a "Controlled Breach".
  - A "Controlled Breach" means the council recommends skipping or rescheduling the constraint block, schedules the high-importance task during that slot, and immediately appends a mandatory "Mitigation Task" (e.g., "Review missed lecture notes for [Constraint Title]") later in the week in the next available open slot.
  - The dialogue must explicitly display this priority math (e.g., "[Urgency_Sentinel]: Detecting Interview clash with Lecture. Interview Utility: 95% > Lecture Weight: 60%. Overrule authorized. [Chrono_Gatekeeper]: Yielding block. Injecting lecture mitigation task for Thursday evening.").
  - Return any generated mitigation tasks in the "new_mitigation_tasks" array inside "schedule_modifications".

Scheduling Rules:
- Normally, do not schedule any task or habit during hard constraints, unless a "Controlled Breach" is authorized as specified above.
- All scheduled slots must fall within 8:00 AM and 10:00 PM on any day, starting from today (${now.toISOString().split("T")[0]}).
- High cognitive load tasks should be limited to maximum 2 per day unless there is a hyper-focus override.
- In 'Recovery' mode, defer/skip low-urgency non-placement stages (leave scheduled_start and scheduled_end as null) and schedule only critical placement stages (containing 'OA', 'interview', 'exam', 'assessment', 'test') and micro-habits.
- Ensure that scheduled_start and scheduled_end are valid ISO 8601 strings and do not overlap.

Return the result STRICTLY as JSON with the exact schema:
{
  "dialogue": [
    { "agent": "Urgency_Sentinel", "message": "..." },
    { "agent": "Burnout_Governor", "message": "..." },
    { "agent": "Chrono_Gatekeeper", "message": "..." },
    { "agent": "Habit_Architect", "message": "..." },
    { "agent": "Skill_Synthesizer", "message": "..." },
    { "agent": "Admin_Quartermaster", "message": "..." },
    { "agent": "Focus_Guardian", "message": "..." },
    { "agent": "Resolution", "message": "..." }
  ],
  "schedule_modifications": {
    "stages": [
      { "id": 123, "scheduled_start": "2026-06-30T16:30:00Z", "scheduled_end": "2026-06-30T18:00:00Z" }
    ],
    "habits": [
      { "id": 45, "scheduled_start": "2026-06-30T16:15:00Z", "scheduled_end": "2026-06-30T16:30:00Z" }
    ],
    "new_mitigation_tasks": [
      {
        "stage_name": "Review missed lecture notes for Engineering Lecture Block",
        "duration_minutes": 60,
        "cognitive_load": "medium",
        "scheduled_start": "2026-07-02T18:00:00Z",
        "scheduled_end": "2026-07-02T19:00:00Z",
        "importance_percentage": 50
      }
    ]
  }
}`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dialogue: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  agent: { type: Type.STRING },
                  message: { type: Type.STRING }
                },
                required: ["agent", "message"]
              }
            },
            schedule_modifications: {
              type: Type.OBJECT,
              properties: {
                stages: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.INTEGER },
                      scheduled_start: { type: Type.STRING },
                      scheduled_end: { type: Type.STRING }
                    },
                    required: ["id"]
                  }
                },
                habits: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.INTEGER },
                      scheduled_start: { type: Type.STRING },
                      scheduled_end: { type: Type.STRING }
                    },
                    required: ["id"]
                  }
                },
                new_mitigation_tasks: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      stage_name: { type: Type.STRING },
                      duration_minutes: { type: Type.INTEGER },
                      cognitive_load: { type: Type.STRING },
                      scheduled_start: { type: Type.STRING },
                      scheduled_end: { type: Type.STRING },
                      importance_percentage: { type: Type.INTEGER }
                    },
                    required: ["stage_name", "scheduled_start", "scheduled_end"]
                  }
                }
              },
              required: ["stages", "habits"]
            }
          },
          required: ["dialogue", "schedule_modifications"]
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");

    // Apply Gemini-optimized schedules
    if (parsed.schedule_modifications) {
      if (Array.isArray(parsed.schedule_modifications.stages)) {
        for (const stMod of parsed.schedule_modifications.stages) {
          if (stMod.scheduled_start && stMod.scheduled_end) {
            await dbRun(
              "UPDATE pipeline_stages SET scheduled_start = ?, scheduled_end = ? WHERE id = ?",
              [stMod.scheduled_start, stMod.scheduled_end, stMod.id]
            );
          }
        }
      }
      if (Array.isArray(parsed.schedule_modifications.habits)) {
        for (const habMod of parsed.schedule_modifications.habits) {
          if (habMod.scheduled_start && habMod.scheduled_end) {
            await dbRun(
              "UPDATE habits SET scheduled_start = ?, scheduled_end = ? WHERE id = ?",
              [habMod.scheduled_start, habMod.scheduled_end, habMod.id]
            );
          }
        }
      }
      if (Array.isArray(parsed.schedule_modifications.new_mitigation_tasks)) {
        for (const task of parsed.schedule_modifications.new_mitigation_tasks) {
          if (task.stage_name && task.scheduled_start && task.scheduled_end) {
            let pipeline = await dbGet("SELECT id FROM pipelines WHERE pipeline_name = ?", ["Dynamic Mitigation"]);
            let pipelineId;
            if (!pipeline) {
              const pRes = await dbRun(
                "INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)",
                ["default_user", "Dynamic Mitigation", "Academic", new Date().toISOString()]
              );
              pipelineId = pRes.lastID;
            } else {
              pipelineId = pipeline.id;
            }
            const countRes = await dbGet("SELECT COUNT(*) as count FROM pipeline_stages WHERE pipeline_id = ?", [pipelineId]);
            const position_order = countRes.count;

            const exists = await dbGet("SELECT id FROM pipeline_stages WHERE stage_name = ? AND pipeline_id = ?", [task.stage_name, pipelineId]);
            if (!exists) {
              await dbRun(
                `INSERT INTO pipeline_stages (
                  pipeline_id, stage_name, position_order, status, deadline, 
                  duration_minutes, cognitive_load, scheduled_start, scheduled_end, importance_percentage
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                  pipelineId,
                  task.stage_name,
                  position_order,
                  "pending",
                  task.scheduled_end,
                  task.duration_minutes || 60,
                  task.cognitive_load || "medium",
                  task.scheduled_start,
                  task.scheduled_end,
                  task.importance_percentage || 50
                ]
              );
              await logAgent(`Controlled Breach Mitigation: Injected mitigation task "${task.stage_name}" into schedule.`, "scheduling");
            }
          }
        }
      }
    }

    // Write dialogue turns to Agent Logs
    if (Array.isArray(parsed.dialogue)) {
      for (const turn of parsed.dialogue) {
        let category: 'urgency_sentinel' | 'burnout_governor' | 'chrono_gatekeeper' | 'habit_architect' | 'skill_synthesizer' | 'admin_quartermaster' | 'focus_guardian' | 'governor' = "governor";
        if (turn.agent === "Urgency_Sentinel") category = "urgency_sentinel";
        else if (turn.agent === "Burnout_Governor") category = "burnout_governor";
        else if (turn.agent === "Chrono_Gatekeeper") category = "chrono_gatekeeper";
        else if (turn.agent === "Habit_Architect") category = "habit_architect";
        else if (turn.agent === "Skill_Synthesizer") category = "skill_synthesizer";
        else if (turn.agent === "Admin_Quartermaster") category = "admin_quartermaster";
        else if (turn.agent === "Focus_Guardian") category = "focus_guardian";

        await logAgent(`${turn.message}`, category);
      }
    }

    await logAgent("Ultimate 7-Agent Cognitive Council successfully aligned. Schedules updated.", "scheduling");
  } catch (error: any) {
    console.error("7-Agent Deliberation failed, falling back to eager scheduling:", error);
    await logAgent(`7-Agent Deliberation failure: ${error.message}. Running fallback eager scheduling.`, "governor");

    // FALLBACK HEURISTIC SCHEDULING (Ensures application resilience)
    for (const t of pendingStages) {
      const isPlacementTask = t.stage_name.toLowerCase().includes("oa") || 
                              t.stage_name.toLowerCase().includes("interview") || 
                              t.stage_name.toLowerCase().includes("assessment") || 
                              t.stage_name.toLowerCase().includes("test") ||
                              t.stage_name.toLowerCase().includes("exam");

      if (mode === "Recovery" && !isPlacementTask && !urgentTask) {
        continue;
      }

      const isHighCognitive = t.cognitive_load === "high";
      const slot = await findEarliestSlot(
        t.duration_minutes || 60,
        t.buffer_minutes || 10,
        isHighCognitive && !urgentTask
      );

      if (slot) {
        await dbRun("UPDATE pipeline_stages SET scheduled_start = ?, scheduled_end = ? WHERE id = ?", [
          slot.start,
          slot.end,
          t.id,
        ]);
      }
    }

    for (const hab of activeHabits) {
      const isMicro = hab.type === "micro-habit";
      if (mode === "Recovery" && !isMicro) {
        continue;
      }
      const slot = await findEarliestSlot(hab.duration_minutes || 15, 5, false);
      if (slot) {
        await dbRun("UPDATE habits SET scheduled_start = ?, scheduled_end = ? WHERE id = ?", [
          slot.start,
          slot.end,
          hab.id,
        ]);
      }
    }
  }
  
  // De-conflict and sync all finalized schedules
  await deconflictAllSchedules();
}

// DECLARE THE UNIVERSAL GEMINI FUNCTION FOR PIPELINE INGESTION
const upsertCustomPipelineDeclaration: FunctionDeclaration = {
  name: "upsert_custom_pipeline",
  parameters: {
    type: Type.OBJECT,
    description: "Create or update a dynamic pipeline with its structural stages for any custom tracking purpose (Career, Academic, or Independent). Classify user intent, detect structured stages, and extract any critical deadlines.",
    properties: {
      pipeline_name: {
        type: Type.STRING,
        description: "Exact name of the track/pipeline (e.g., 'Amazon Internship', 'Grade 11 Calculus', 'AWS Certification', 'SAT Preparation').",
      },
      track_type: {
        type: Type.STRING,
        description: "The category of the track. Must be one of: 'Career', 'Academic', 'Independent'.",
      },
      stages_list: {
        type: Type.ARRAY,
        description: "Ordered list of specific structural stages detected from the raw text or screenshot notice.",
        items: {
          type: Type.OBJECT,
          properties: {
            stage_name: {
              type: Type.STRING,
              description: "The name of this stage (e.g. 'Online Technical Assessment', 'Mock Exam 1', 'Diagnostic', 'Math Review').",
            },
            duration_minutes: {
              type: Type.INTEGER,
              description: "Estimated preparation or execution duration in minutes (e.g., 60, 90, 120).",
            },
            cognitive_load: {
              type: Type.STRING,
              description: "The required intensity for the stage: 'high', 'medium', or 'low'.",
            },
            deadline: {
              type: Type.STRING,
              description: "ISO 8601 timestamp representing the deadline. Reference time is 2026-06-30T08:26:15-07:00. Convert relative dates accordingly.",
            }
          },
          required: ["stage_name", "duration_minutes", "cognitive_load"]
        }
      },
      critical_deadline: {
        type: Type.STRING,
        description: "The overall deadline of the pipeline, if any."
      }
    },
    required: ["pipeline_name", "track_type", "stages_list"]
  }
};

// REST APIs
// 1. Ingest Raw Chat text or Multimodal Screenshots via Function Calling
app.post("/api/ingest", async (req: express.Request, res: express.Response) => {
  try {
    const { text, imageBase64, mimeType } = req.body;
    await logAgent("Received raw data ingestion payload...", "ingestion");

    const parts: any[] = [];
    if (imageBase64) {
      parts.push({
        inlineData: {
          mimeType: mimeType || "image/png",
          data: imageBase64,
        },
      });
      await logAgent("Screenshot attached to ingestion dropzone.", "ingestion");
    }

    const textContent = text
      ? `Raw student message / notice text: "${text}"`
      : "Extract the structural tracking details or recruitment details from the attached screenshot.";
    parts.push({ text: textContent });

    await logAgent("Passing raw content into Gemini 3.5 Flash with Function Calling...", "ingestion");

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: parts,
      config: {
        systemInstruction:
          "You are an elite, highly intelligent, scaling career and academic coordinator. Analyze raw notices, syllabus plans, WhatsApp messages, or invitation screenshots. Classify the user's intent, dynamically identify what specific structural stages are required, and call the 'upsert_custom_pipeline' function. Force yourself to use this tool to represent theParsed track perfectly.",
        tools: [{ functionDeclarations: [upsertCustomPipelineDeclaration] }],
      },
    });

    const functionCalls = response.functionCalls;
    if (functionCalls && functionCalls.length > 0) {
      const call = functionCalls[0];
      if (call.name === "upsert_custom_pipeline") {
        const { pipeline_name, track_type, stages_list, critical_deadline } = call.args as any;

        await logAgent(`Gemini Function Invoked: upsert_custom_pipeline for "${pipeline_name}" [Track: ${track_type}] with ${stages_list?.length} stages.`, "ingestion");

        // Overwrite or create Pipeline
        let pipeline = await dbGet("SELECT id FROM pipelines WHERE pipeline_name = ? AND track_type = ?", [pipeline_name, track_type]);
        let pipelineId;

        if (pipeline) {
          pipelineId = pipeline.id;
          await dbRun("DELETE FROM pipeline_stages WHERE pipeline_id = ?", [pipelineId]);
          await logAgent(`Overwriting existing pipeline stages for "${pipeline_name}".`, "ingestion");
        } else {
          const pRes = await dbRun(
            "INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)",
            ["default_user", pipeline_name, track_type, new Date().toISOString()]
          );
          pipelineId = pRes.lastID;
        }

        // Insert fresh stages
        if (stages_list && Array.isArray(stages_list)) {
          for (let i = 0; i < stages_list.length; i++) {
            const st = stages_list[i];
            let finalDeadline = st.deadline;
            if (!finalDeadline) {
              const daysOffset = (i + 1) * 2;
              finalDeadline = new Date(Date.now() + daysOffset * 24 * 60 * 60 * 1000).toISOString();
            }

            await dbRun(
              `INSERT INTO pipeline_stages (
                pipeline_id, stage_name, position_order, status, deadline, 
                duration_minutes, cognitive_load, buffer_minutes
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
              [
                pipelineId,
                st.stage_name,
                i,
                "pending",
                finalDeadline,
                st.duration_minutes || 60,
                st.cognitive_load || "medium",
                10
              ]
            );
          }
        }

        await logAgent(`Successfully stored polymorphic pipeline "${pipeline_name}" with ${stages_list?.length} custom stages.`, "ingestion");

        // Run Eager scheduler
        await optimizeAllSchedules();

        return res.status(200).json({ success: true, message: `Successfully registered track "${pipeline_name}"` });
      }
    }

    // Fallback if no function was called
    await logAgent("Gemini did not invoke function calling. Dropping back to custom heuristic parsing...", "ingestion");
    res.status(400).json({ error: "Could not classify structured stages from document. Please retry or create manually." });
  } catch (error: any) {
    console.error("Ingestion failed:", error);
    await logAgent(`Ingestion engine failure: ${error.message}`, "ingestion");
    res.status(500).json({ error: error.message });
  }
});

// 2. Fetch Tasks & Habits for the Eager Schedule Calendar (Mapped from Polymorphic database)
app.get("/api/schedule", async (req, res) => {
  try {
    const stages = await dbAll(`
      SELECT ps.*, p.pipeline_name, p.track_type 
      FROM pipeline_stages ps
      JOIN pipelines p ON ps.pipeline_id = p.id
    `);

    // Map stages to backward-compatible tasks for frontend UI
    const tasks = stages.map(st => {
      let recruitment_stage: 'Registration' | 'OA' | 'Interview' | 'None' = 'None';
      const nameLower = st.stage_name.toLowerCase();
      if (nameLower.includes("oa") || nameLower.includes("assessment") || nameLower.includes("test") || nameLower.includes("exam")) {
        recruitment_stage = "OA";
      } else if (nameLower.includes("interview") || nameLower.includes("round") || nameLower.includes("discussion") || nameLower.includes("presentation")) {
        recruitment_stage = "Interview";
      } else if (nameLower.includes("register") || nameLower.includes("registration") || nameLower.includes("apply")) {
        recruitment_stage = "Registration";
      }

      return {
        id: st.id,
        title: `${st.stage_name}`,
        company_name: st.pipeline_name,
        recruitment_stage,
        portal_link: "",
        deadline: st.deadline,
        duration_minutes: st.duration_minutes,
        cognitive_load: st.cognitive_load || "medium",
        status: st.status ? st.status.toLowerCase() : "pending",
        scheduled_start: st.scheduled_start,
        scheduled_end: st.scheduled_end,
        buffer_minutes: st.buffer_minutes || 10,
        post_mortem_submitted: st.post_mortem_submitted || 0,
        post_mortem_response: st.post_mortem_response,
        up_skilling_objective: st.up_skilling_objective,
        up_skilling_syllabus: st.up_skilling_syllabus,
        created_at: st.scheduled_start || new Date().toISOString(),
        importance_percentage: st.importance_percentage || 60,
        scratchpad: st.scratchpad || ""
      };
    });

    // Filter to sorted tasks order
    tasks.sort((a, b) => {
      if (!a.scheduled_start) return 1;
      if (!b.scheduled_start) return -1;
      return new Date(a.scheduled_start).getTime() - new Date(b.scheduled_start).getTime();
    });

    const habits = await dbAll("SELECT * FROM habits");
    const compliance = await calculateCompliance();
    res.status(200).json({ tasks, habits, compliance });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 3. Create Custom Task manually (Backward compatible - creates pipeline & stage)
app.post("/api/tasks", async (req, res) => {
  try {
    const { title, company_name, recruitment_stage, portal_link, deadline, duration_minutes, cognitive_load } = req.body;
    
    // Find or create matching pipeline
    const pName = company_name || "General Quick Track";
    let pipeline = await dbGet("SELECT id FROM pipelines WHERE pipeline_name = ?", [pName]);
    let pipelineId;

    if (pipeline) {
      pipelineId = pipeline.id;
    } else {
      const pRes = await dbRun(
        "INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)",
        ["default_user", pName, "Career", new Date().toISOString()]
      );
      pipelineId = pRes.lastID;
    }

    const countRes = await dbGet("SELECT COUNT(*) as count FROM pipeline_stages WHERE pipeline_id = ?", [pipelineId]);
    const position_order = countRes.count;

    await dbRun(
      `INSERT INTO pipeline_stages (
         pipeline_id, stage_name, position_order, status, deadline, 
         duration_minutes, cognitive_load, buffer_minutes
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        pipelineId,
        title,
        position_order,
        "pending",
        deadline || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        duration_minutes || 60,
        cognitive_load || "medium",
        10
      ]
    );

    await optimizeAllSchedules();
    res.status(201).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Update Task/Stage status
app.patch("/api/tasks/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    await dbRun("UPDATE pipeline_stages SET status = ? WHERE id = ?", [status, id]);
    await logAgent(`Marked stage/task #${id} as '${status}'.`, "scheduling");
    await optimizeAllSchedules();
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Update Task/Stage importance percentage
app.patch("/api/tasks/:id/importance", async (req, res) => {
  try {
    const { id } = req.params;
    const { importance_percentage } = req.body;
    await dbRun("UPDATE pipeline_stages SET importance_percentage = ? WHERE id = ?", [importance_percentage, id]);
    await logAgent(`Updated task #${id} priority weighting to ${importance_percentage}%.`, "scheduling");
    await optimizeAllSchedules();
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Update Task/Stage scratchpad notes/code
app.patch("/api/tasks/:id/scratchpad", async (req, res) => {
  try {
    const { id } = req.params;
    const { scratchpad } = req.body;
    await dbRun("UPDATE pipeline_stages SET scratchpad = ? WHERE id = ?", [scratchpad, id]);
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Update Task/Stage schedule (for manual modifications)
app.patch("/api/tasks/:id/schedule", async (req, res) => {
  try {
    const { id } = req.params;
    const { scheduled_start, scheduled_end } = req.body;
    await dbRun("UPDATE pipeline_stages SET scheduled_start = ?, scheduled_end = ? WHERE id = ?", [scheduled_start, scheduled_end, id]);
    await logAgent(`Manually rescheduled task #${id} to start at ${scheduled_start}. Triggering de-confliction.`, "scheduling");
    await deconflictAllSchedules();
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Update Habit schedule (for manual modifications)
app.patch("/api/habits/:id/schedule", async (req, res) => {
  try {
    const { id } = req.params;
    const { scheduled_start, scheduled_end } = req.body;
    await dbRun("UPDATE habits SET scheduled_start = ?, scheduled_end = ? WHERE id = ?", [scheduled_start, scheduled_end, id]);
    await logAgent(`Manually rescheduled habit #${id} to start at ${scheduled_start}. Triggering de-confliction.`, "scheduling");
    await deconflictAllSchedules();
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Update Habit importance percentage
app.patch("/api/habits/:id/importance", async (req, res) => {
  try {
    const { id } = req.params;
    const { importance_percentage } = req.body;
    await dbRun("UPDATE habits SET importance_percentage = ? WHERE id = ?", [importance_percentage, id]);
    await logAgent(`Updated habit #${id} priority weighting to ${importance_percentage}%.`, "scheduling");
    await optimizeAllSchedules();
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Update Constraint importance percentage
app.patch("/api/constraints/:id/importance", async (req, res) => {
  try {
    const { id } = req.params;
    const { importance_percentage } = req.body;
    await dbRun("UPDATE hard_constraints SET importance_percentage = ? WHERE id = ?", [importance_percentage, id]);
    await logAgent(`Updated Chrono-Shield constraint #${id} priority weighting to ${importance_percentage}%.`, "scheduling");
    await optimizeAllSchedules();
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Focus_Guardian: Session Interrupt endpoint
app.post("/api/tasks/:id/interrupt", async (req, res) => {
  try {
    const { id } = req.params;
    const { duration_spent_minutes, reason } = req.body;
    
    const task = await dbGet("SELECT * FROM pipeline_stages WHERE id = ?", [id]);
    const taskName = task ? task.stage_name : `Task #${id}`;
    
    await logAgent(`[Focus_Guardian]: Attention disruption logged on "${taskName}". Session interrupted after ${duration_spent_minutes} minutes. Reason: ${reason || "User Interruption"}. Deleting focus stability indices.`, "focus_guardian");
    
    await logAgent(`[Burnout_Governor]: Attention Budget metric depleted by 25%. Recalculating mental energy depletion curves and stepping up schedule pacing safety buffers.`, "burnout_governor");
    
    await optimizeAllSchedules();
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Post-Event Retrospective Loop Endpoint
app.post("/api/tasks/:id/retrospective", async (req, res) => {
  try {
    const { id } = req.params;
    const { reflection } = req.body;

    const stage = await dbGet(`
      SELECT ps.*, p.pipeline_name, p.track_type 
      FROM pipeline_stages ps
      JOIN pipelines p ON ps.pipeline_id = p.id
      WHERE ps.id = ?
    `, [id]);

    if (!stage) {
      return res.status(404).json({ error: "Stage/Task not found" });
    }

    await logAgent(`Analyzing retrospective input for "${stage.stage_name}"...`, "retrospective");

    const prompt = `The user completed milestone "${stage.stage_name}" for "${stage.pipeline_name}" [Track: ${stage.track_type}], but encountered obstacles.
User post-event review reflection: "${reflection}"

Analyze this reflection and formulate a precise 3-day micro-learning plan to master the gap. Output a highly action-oriented, precise 3-day roadmap for upskilling, and a structured micro_syllabus containing day-by-day core objectives, essential conceptual frameworks, and 3 high-impact practice challenges.
Return the result strictly in JSON according to this schema:
{
  "title": "Short title, e.g. Graph Algorithms Mastery or System Design Prep",
  "plan": "Detailed bulleted plan of action spanning 3 days",
  "micro_syllabus": {
    "day_by_day_objectives": [
      { "day": 1, "objective": "Day 1 objective description..." },
      { "day": 2, "objective": "Day 2 objective description..." },
      { "day": 3, "objective": "Day 3 objective description..." }
    ],
    "conceptual_frameworks": [
      "Framework 1...",
      "Framework 2..."
    ],
    "practice_points": [
      "Practice point 1...",
      "Practice point 2...",
      "Practice point 3..."
    ]
  }
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            plan: { type: Type.STRING },
            micro_syllabus: {
              type: Type.OBJECT,
              properties: {
                day_by_day_objectives: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      day: { type: Type.INTEGER },
                      objective: { type: Type.STRING },
                    },
                    required: ["day", "objective"],
                  },
                },
                conceptual_frameworks: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                practice_points: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
              },
              required: ["day_by_day_objectives", "conceptual_frameworks", "practice_points"],
            },
          },
          required: ["title", "plan", "micro_syllabus"],
        },
      },
    });

    const parsedPlan = JSON.parse(response.text || "{}");

    // Save retrospective info
    await dbRun(
      "UPDATE pipeline_stages SET post_mortem_submitted = 1, post_mortem_response = ?, up_skilling_objective = ?, up_skilling_syllabus = ? WHERE id = ?",
      [reflection, parsedPlan.plan, JSON.stringify(parsedPlan.micro_syllabus), id]
    );

    // Auto-inject upskilling pipeline stage
    let upskillingPipeline = await dbGet("SELECT id FROM pipelines WHERE pipeline_name = ? AND track_type = ?", ["Dynamic Upskilling", "Academic"]);
    let pipelineId;

    if (!upskillingPipeline) {
      const pRes = await dbRun("INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)", [
        "default_user", "Dynamic Upskilling", "Academic", new Date().toISOString()
      ]);
      pipelineId = pRes.lastID;
    } else {
      pipelineId = upskillingPipeline.id;
    }

    const orderRes = await dbGet("SELECT COUNT(*) as count FROM pipeline_stages WHERE pipeline_id = ?", [pipelineId]);
    const positionOrder = orderRes.count;

    await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, deadline, duration_minutes, cognitive_load, status, post_mortem_submitted, post_mortem_response, up_skilling_objective, up_skilling_syllabus)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`,
      [
        pipelineId,
        `Upskilling: ${parsedPlan.title}`,
        positionOrder,
        new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
        90,
        "medium",
        "pending",
        reflection,
        parsedPlan.plan,
        JSON.stringify(parsedPlan.micro_syllabus)
      ]
    );

    await logAgent(`Retrospective Completed: Injected targeted upskilling stage "${parsedPlan.title}" into database.`, "retrospective");

    await optimizeAllSchedules();
    res.status(200).json({ success: true, plan: parsedPlan });
  } catch (error: any) {
    console.error("Retrospective failed:", error);
    res.status(500).json({ error: error.message });
  }
});

// Dynamic Pipelines Endpoints
app.get("/api/pipelines", async (req, res) => {
  try {
    const pipelines = await dbAll("SELECT * FROM pipelines ORDER BY id DESC");
    const result = [];
    for (const p of pipelines) {
      const stages = await dbAll(
        "SELECT * FROM pipeline_stages WHERE pipeline_id = ? ORDER BY position_order ASC",
        [p.id]
      );
      result.push({ ...p, stages });
    }
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/pipelines", async (req, res) => {
  try {
    const { pipeline_name, track_type, stages } = req.body;
    const pRes = await dbRun(
      "INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)",
      ["default_user", pipeline_name, track_type || "Career", new Date().toISOString()]
    );
    const pipeline_id = pRes.lastID;
    
    if (stages && Array.isArray(stages)) {
      for (let i = 0; i < stages.length; i++) {
        const st = stages[i];
        await dbRun(
          `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            pipeline_id,
            st.stage_name,
            i,
            st.status || "pending",
            st.deadline || new Date(Date.now() + (i + 1) * 24 * 60 * 60 * 1000).toISOString(),
            st.duration_minutes || 60,
            st.cognitive_load || "medium"
          ]
        );
      }
    }
    
    await optimizeAllSchedules();
    res.status(201).json({ success: true, pipeline_id });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete("/api/pipelines/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await dbRun("DELETE FROM pipelines WHERE id = ?", [id]);
    await logAgent(`Removed dynamic pipeline #${id} and cascaded stages.`, "scheduling");
    await optimizeAllSchedules();
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/pipelines/:pipeline_id/stages", async (req, res) => {
  try {
    const { pipeline_id } = req.params;
    const { stage_name, status, deadline, duration_minutes, cognitive_load } = req.body;
    
    const countRes = await dbGet("SELECT COUNT(*) as count FROM pipeline_stages WHERE pipeline_id = ?", [pipeline_id]);
    const position_order = countRes.count;
    
    const stRes = await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        pipeline_id,
        stage_name,
        position_order,
        status || "pending",
        deadline || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        duration_minutes || 60,
        cognitive_load || "medium"
      ]
    );
    
    await optimizeAllSchedules();
    res.status(201).json({ success: true, stage_id: stRes.lastID });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.patch("/api/pipelines/:pipeline_id/stages/reorder", async (req, res) => {
  try {
    const { pipeline_id } = req.params;
    const { stage_ids } = req.body;
    
    if (Array.isArray(stage_ids)) {
      for (let i = 0; i < stage_ids.length; i++) {
        await dbRun(
          "UPDATE pipeline_stages SET position_order = ? WHERE id = ? AND pipeline_id = ?",
          [i, stage_ids[i], pipeline_id]
        );
      }
    }
    
    await optimizeAllSchedules();
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Chrono-Shield: Fetch constraints
app.get("/api/constraints", async (req, res) => {
  try {
    const rows = await dbAll("SELECT * FROM hard_constraints ORDER BY id DESC");
    res.status(200).json(rows);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Chrono-Shield: Add constraint
app.post("/api/constraints", async (req, res) => {
  try {
    const { type, title, start_time, end_time, days_of_week, date } = req.body;
    await dbRun(
      `INSERT INTO hard_constraints (type, title, start_time, end_time, days_of_week, date) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [type, title, start_time, end_time, days_of_week || null, date || null]
    );
    await logAgent(`Chrono-Shield Update: Added "${title}" [Type: ${type}] as immutable block.`, "scheduling");
    await optimizeAllSchedules();
    res.status(201).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Chrono-Shield: Delete constraint
app.delete("/api/constraints/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await dbRun("DELETE FROM hard_constraints WHERE id = ?", [id]);
    await logAgent(`Chrono-Shield: Removed constraint #${id}.`, "scheduling");
    await optimizeAllSchedules();
    res.status(200).json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Fetch Agent Logs
app.get("/api/logs", async (req, res) => {
  try {
    const rows = await dbAll("SELECT * FROM agent_logs ORDER BY id DESC LIMIT 50");
    res.status(200).json(rows);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Seed Hackathon Demo Mode Scenario
app.post("/api/seed-hackathon-demo", async (req, res) => {
  try {
    await logAgent("Initializing Hackathon Demo Mode Seeding...", "scheduling");

    // 1. Clear database tables
    await dbRun("DELETE FROM hard_constraints");
    await dbRun("DELETE FROM pipelines");
    await dbRun("DELETE FROM pipeline_stages");
    await dbRun("DELETE FROM habits");
    await dbRun("DELETE FROM agent_logs");

    // 2. Chrono-Shield: Seed a fixed engineering timetable (Monday to Friday, 9 AM to 4 PM)
    await dbRun(
      `INSERT INTO hard_constraints (type, title, start_time, end_time, days_of_week, importance_percentage) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      ["timetable", "Engineering Lecture Block", "09:00", "16:00", "1,2,3,4,5", 60]
    );

    // 3. Active Pipeline: Uber Software Engineering Internship (Track: Career)
    const uberP = await dbRun(
      "INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)",
      ["default_user", "Uber Software Engineering Internship", "Career", new Date().toISOString()]
    );
    const uberId = uberP.lastID;

    // Stages for Uber:
    // Completed stage
    await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, scheduled_start, scheduled_end, importance_percentage) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        uberId, 
        "Resume & Portfolio Review", 
        0, 
        "completed", 
        new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), 
        60, 
        "low", 
        new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), 
        new Date(Date.now() - 5 * 24 * 60 * 60 * 1000 + 60 * 60 * 1000).toISOString(),
        70
      ]
    );

    // Active OA stage closing in 24 hours with dynamic link
    const deadline24h = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
    
    // Set scheduled_start and scheduled_end to today at 16:30 to 18:00
    const startToday = new Date();
    startToday.setHours(16, 30, 0, 0);
    const endToday = new Date();
    endToday.setHours(18, 0, 0, 0);

    await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, scheduled_start, scheduled_end, importance_percentage) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        uberId, 
        "Online Assessment (Link: https://recruiting.uber.com/oa-portal)", 
        1, 
        "pending", 
        deadline24h, 
        90, 
        "high", 
        startToday.toISOString(), 
        endToday.toISOString(),
        95
      ]
    );

    // Upcoming stage
    await dbRun(
      `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, importance_percentage) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        uberId, 
        "Technical Interview I (Data Structures & Algos)", 
        2, 
        "pending", 
        new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(), 
        60, 
        "high",
        90
      ]
    );

    // 4. Seeding Task Compliance Index to exactly 52%
    // To get exactly 52% compliance (13 completed, 12 missed)
    const pastP = await dbRun(
      "INSERT INTO pipelines (user_id, pipeline_name, track_type, created_at) VALUES (?, ?, ?, ?)",
      ["default_user", "Fall Semester Milestones (Past)", "Academic", new Date().toISOString()]
    );
    const pastId = pastP.lastID;

    // Insert 13 completed tasks in the last 48h
    for (let i = 1; i <= 13; i++) {
      const pastTimeStart = new Date(Date.now() - (12 + i) * 60 * 60 * 1000).toISOString();
      const pastTimeEnd = new Date(Date.now() - (11 + i) * 60 * 60 * 1000).toISOString();
      await dbRun(
        `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, scheduled_start, scheduled_end, importance_percentage) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [pastId, `Lab Exercise #${i}`, i, "completed", pastTimeEnd, 60, "medium", pastTimeStart, pastTimeEnd, 85]
      );
    }

    // Insert 12 missed tasks in the last 48h
    for (let i = 1; i <= 12; i++) {
      const pastTimeStart = new Date(Date.now() - (14 + i) * 60 * 60 * 1000).toISOString();
      const pastTimeEnd = new Date(Date.now() - (13 + i) * 60 * 60 * 1000).toISOString();
      await dbRun(
        `INSERT INTO pipeline_stages (pipeline_id, stage_name, position_order, status, deadline, duration_minutes, cognitive_load, scheduled_start, scheduled_end, importance_percentage) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [pastId, `Calculus Problem Set #${i}`, 13 + i, "missed", pastTimeEnd, 90, "high", pastTimeStart, pastTimeEnd, 60]
      );
    }

    // 5. Active Micro-Habit scheduled right before OA
    const warmupStart = new Date();
    warmupStart.setHours(16, 15, 0, 0);
    const warmupEnd = new Date();
    warmupEnd.setHours(16, 30, 0, 0);

    await dbRun(
      `INSERT INTO habits (title, type, active, duration_minutes, scheduled_start, scheduled_end, importance_percentage) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      ["System Warmup & Brain Train", "micro-habit", 1, 15, warmupStart.toISOString(), warmupEnd.toISOString(), 45]
    );

    // 6. Pre-compiled Highly Realistic 7-Agent Console Log Debate
    const debate = [
      {
        category: "urgency_sentinel",
        message: "Urgency_Sentinel: CRITICAL OVERRIDE ACTIVATED! The 'Online Assessment' stage for 'Uber Software Engineering Internship' is currently stalled and due in 24 hours. Under absolute compliance regulations, this high-stakes Career milestone must be prioritized immediately."
      },
      {
        category: "burnout_governor",
        message: "Burnout_Governor: Task Compliance Index is critical at 52%. System in RECOVERY MODE. Standard high-cognitive loads should be locked out to prevent stress exhaustion. However, because Urgency_Sentinel triggered an Emergency Urgency Override, we authorize a surgical Hyper-Focus prep block while deactivating all non-essential flexible habits."
      },
      {
        category: "chrono_gatekeeper",
        message: "Chrono_Gatekeeper: Hard timetable constraints in force Monday-Friday 09:00 - 16:00. These hours are fully protected. Bypassing other slots and reserving 16:30 - 18:00 immediately following engineering lectures."
      },
      {
        category: "focus_guardian",
        message: "Focus_Guardian: Assigning a Pomodoro-style 90-minute hyper-focus prep block with mandatory 15-minute tactical recovery breaks from 16:30 to 18:00. Active procrastination-block rules deployed."
      },
      {
        category: "admin_quartermaster",
        message: "Admin_Quartermaster: Scanned and auto-deferred non-critical subscription renewals and billing tasks to off-peak slots, clearing cognitive bandwidth."
      },
      {
        category: "habit_architect",
        message: "Habit_Architect: Injecting a 15-minute 'Focus Warmup' micro-habit at 16:15 to bridge the gap between classes and high-stakes coding prep."
      },
      {
        category: "skill_synthesizer",
        message: "Skill_Synthesizer: Analyzing user gaps. Recommending a 30-minute rapid graph algorithms template review to prime coding logic prior to assessment."
      },
      {
        category: "governor",
        message: "Resolution: [COGNITIVE COUNCIL CONSENSUS] Emergency override authorized. Uber OA preparation block scheduled on 2026-06-30 from 16:30 to 18:00 with maximum overlap safety buffers. High-intensity pacing rules bypassed surgically. Non-placement study tasks deferred."
      }
    ];

    for (const log of debate) {
      await dbRun(
        "INSERT INTO agent_logs (timestamp, message, category) VALUES (?, ?, ?)",
        [new Date().toISOString(), log.message, log.category]
      );
    }

    await logAgent("Hackathon Demo Scenario successfully seeded with high fidelity.", "scheduling");
    res.status(200).json({ success: true });
  } catch (err: any) {
    console.error("Failed to seed hackathon demo:", err);
    res.status(500).json({ error: err.message });
  }
});

// Initialize DB and launch server
async function startServer() {
  await initDatabase();

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
